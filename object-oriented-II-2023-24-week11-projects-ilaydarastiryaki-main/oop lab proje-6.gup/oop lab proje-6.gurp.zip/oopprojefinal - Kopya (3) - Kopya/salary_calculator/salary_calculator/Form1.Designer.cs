﻿namespace salary_calculator
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblCalismaSaatleri;
        private System.Windows.Forms.TextBox txtCalismaSaatleri;
        private System.Windows.Forms.Label lblPozisyon;
        private System.Windows.Forms.TextBox txtPozisyon;
        private System.Windows.Forms.Button btnMaasiHesapla;
        private System.Windows.Forms.Label lblHesaplananMaas;
        private System.Windows.Forms.Label lblMaas;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblCalismaSaatleri = new System.Windows.Forms.Label();
            this.txtCalismaSaatleri = new System.Windows.Forms.TextBox();
            this.lblPozisyon = new System.Windows.Forms.Label();
            this.txtPozisyon = new System.Windows.Forms.TextBox();
            this.btnMaasiHesapla = new System.Windows.Forms.Button();
            this.lblHesaplananMaas = new System.Windows.Forms.Label();
            this.lblMaas = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblCalismaSaatleri
            // 
            this.lblCalismaSaatleri.AutoSize = true;
            this.lblCalismaSaatleri.Location = new System.Drawing.Point(13, 13);
            this.lblCalismaSaatleri.Name = "lblCalismaSaatleri";
            this.lblCalismaSaatleri.Size = new System.Drawing.Size(84, 13);
            this.lblCalismaSaatleri.TabIndex = 0;
            this.lblCalismaSaatleri.Text = "Çalışma Saatleri:";
            // 
            // txtCalismaSaatleri
            // 
            this.txtCalismaSaatleri.Location = new System.Drawing.Point(102, 10);
            this.txtCalismaSaatleri.Name = "txtCalismaSaatleri";
            this.txtCalismaSaatleri.Size = new System.Drawing.Size(100, 20);
            this.txtCalismaSaatleri.TabIndex = 1;
            // 
            // lblPozisyon
            // 
            this.lblPozisyon.AutoSize = true;
            this.lblPozisyon.Location = new System.Drawing.Point(13, 39);
            this.lblPozisyon.Name = "lblPozisyon";
            this.lblPozisyon.Size = new System.Drawing.Size(52, 13);
            this.lblPozisyon.TabIndex = 2;
            this.lblPozisyon.Text = "Pozisyon:";
            // 
            // txtPozisyon
            // 
            this.txtPozisyon.Location = new System.Drawing.Point(102, 36);
            this.txtPozisyon.Name = "txtPozisyon";
            this.txtPozisyon.Size = new System.Drawing.Size(100, 20);
            this.txtPozisyon.TabIndex = 3;
            // 
            // btnMaasiHesapla
            // 
            this.btnMaasiHesapla.Location = new System.Drawing.Point(102, 62);
            this.btnMaasiHesapla.Name = "btnMaasiHesapla";
            this.btnMaasiHesapla.Size = new System.Drawing.Size(100, 23);
            this.btnMaasiHesapla.TabIndex = 4;
            this.btnMaasiHesapla.Text = "Maaşı Hesapla";
            this.btnMaasiHesapla.UseVisualStyleBackColor = true;
            this.btnMaasiHesapla.Click += new System.EventHandler(this.maasiHesapla_Click);
            // 
            // lblHesaplananMaas
            // 
            this.lblHesaplananMaas.AutoSize = true;
            this.lblHesaplananMaas.Location = new System.Drawing.Point(13, 98);
            this.lblHesaplananMaas.Name = "lblHesaplananMaas";
            this.lblHesaplananMaas.Size = new System.Drawing.Size(96, 13);
            this.lblHesaplananMaas.TabIndex = 5;
            this.lblHesaplananMaas.Text = "Hesaplanan Maaş:";
            // 
            // lblMaas
            // 
            this.lblMaas.AutoSize = true;
            this.lblMaas.Location = new System.Drawing.Point(110, 98);
            this.lblMaas.Name = "lblMaas";
            this.lblMaas.Size = new System.Drawing.Size(0, 13);
            this.lblMaas.TabIndex = 6;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(284, 161);
            this.Controls.Add(this.lblMaas);
            this.Controls.Add(this.lblHesaplananMaas);
            this.Controls.Add(this.btnMaasiHesapla);
            this.Controls.Add(this.txtPozisyon);
            this.Controls.Add(this.lblPozisyon);
            this.Controls.Add(this.txtCalismaSaatleri);
            this.Controls.Add(this.lblCalismaSaatleri);
            this.Name = "Form1";
            this.Text = "Maaş Hesaplayıcı";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
