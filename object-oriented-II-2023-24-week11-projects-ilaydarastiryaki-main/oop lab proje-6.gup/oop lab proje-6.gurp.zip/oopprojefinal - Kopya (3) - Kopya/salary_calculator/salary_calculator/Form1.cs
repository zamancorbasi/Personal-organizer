﻿using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Collections.Generic;

namespace salary_calculator
{
    public partial class Form1 : Form
    {
        private string CsvFilePath => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "salary_data.csv");

        public Form1()
        {
            InitializeComponent();
            EnsureCsvFileExists();
        }

        private void maasiHesapla_Click(object sender, EventArgs e)
        {
            try
            {
                decimal baseSalary = 5000m; // Temel maaş (örnek olarak 5000 TL)
                int workHours = int.Parse(txtCalismaSaatleri.Text);
                string position = txtPozisyon.Text;
                decimal calculatedSalary = CalculateSalary(baseSalary, workHours, position);

                lblMaas.Text = $"{calculatedSalary:C2}"; // Para birimi formatında gösterim

                SaveSalaryData(txtCalismaSaatleri.Text, txtPozisyon.Text, calculatedSalary);
            }
            catch (FormatException)
            {
                MessageBox.Show("Lütfen geçerli çalışma saatleri girin.", "Giriş Hatası", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private decimal CalculateSalary(decimal baseSalary, int workHours, string position)
        {
            decimal hourlyRate = baseSalary / 160; // Ayda 160 çalışma saati varsayımı
            decimal salary = hourlyRate * workHours;

            if (position.ToLower() == "part-time")
            {
                salary *= 0.5m; // Part-time pozisyon için %50 indirim
            }

            return salary;
        }

        private void SaveSalaryData(string workHours, string position, decimal calculatedSalary)
        {
            string newLine = $"{workHours},{position},{calculatedSalary}";
            List<string> lines = File.Exists(CsvFilePath) ? File.ReadAllLines(CsvFilePath).ToList() : new List<string> { "workHours,position,calculatedSalary" };

            bool recordExists = false;
            for (int i = 1; i < lines.Count; i++)
            {
                var parts = lines[i].Split(',');
                if (parts[0] == workHours && parts[1] == position)
                {
                    lines[i] = newLine;
                    recordExists = true;
                    break;
                }
            }

            if (!recordExists)
            {
                lines.Add(newLine);
            }

            File.WriteAllLines(CsvFilePath, lines);
        }

        private void EnsureCsvFileExists()
        {
            if (!File.Exists(CsvFilePath))
            {
                var header = "workHours,position,calculatedSalary";
                File.WriteAllText(CsvFilePath, header + Environment.NewLine);
            }
        }
    }
}
