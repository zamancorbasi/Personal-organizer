﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO; // Bu satırı ekleyin


namespace Not_Defteri
{
    public partial class Form1 : Form
    {
        private string filePath = "notes.csv";
        private List<string> notes = new List<string>();

        public Form1()
        {
            InitializeComponent();
            LoadNotes();
        }

        // Notları yükleme
        private void LoadNotes()
        {
            if (File.Exists(filePath))
            {
                notes = File.ReadAllLines(filePath).ToList();
            }
            dgvNotes.DataSource = notes.Select(n => new { Note = n }).ToList();
        }

        // Notları kaydetme
        private void SaveNotes()
        {
            File.WriteAllLines(filePath, notes);
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtNote.Text))
            {
                notes.Add(txtNote.Text);
                SaveNotes();
                LoadNotes();
                txtNote.Clear();
            }
            else
            {
                MessageBox.Show("Lütfen bir not girin.");
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            if (dgvNotes.SelectedRows.Count > 0 && !string.IsNullOrWhiteSpace(txtNote.Text))
            {
                int index = dgvNotes.SelectedRows[0].Index;
                notes[index] = txtNote.Text;
                SaveNotes();
                LoadNotes();
                txtNote.Clear();
            }
            else
            {
                MessageBox.Show("Lütfen güncellenecek notu seçin ve yeni notu girin.");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvNotes.SelectedRows.Count > 0)
            {
                int index = dgvNotes.SelectedRows[0].Index;
                notes.RemoveAt(index);
                SaveNotes();
                LoadNotes();
                txtNote.Clear();
            }
            else
            {
                MessageBox.Show("Lütfen silinecek notu seçin.");
            }
        }

        private void btnList_Click(object sender, EventArgs e)
        {
            LoadNotes();
        }
    }
}
