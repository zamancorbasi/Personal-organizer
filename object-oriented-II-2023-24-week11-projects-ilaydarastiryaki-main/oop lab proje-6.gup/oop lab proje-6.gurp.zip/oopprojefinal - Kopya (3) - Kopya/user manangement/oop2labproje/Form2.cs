﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace oop2labproje
{
    public partial class AdminValidationForm : Form
    {
        public string AdminUsername { get; private set; }

        public AdminValidationForm()
        {
            InitializeComponent();
        }

      
        private void btnValidate_Click_1(object sender, EventArgs e)
        {
            AdminUsername = txtAdminUsername.Text;
            this.DialogResult = DialogResult.OK;
            this.Close();

        }

        private void txtAdminUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void AdminValidationForm_Load(object sender, EventArgs e)
        {

        }
    }

}
