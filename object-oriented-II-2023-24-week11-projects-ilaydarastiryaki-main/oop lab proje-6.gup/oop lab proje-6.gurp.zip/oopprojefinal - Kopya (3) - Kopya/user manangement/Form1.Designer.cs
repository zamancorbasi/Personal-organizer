﻿namespace oop2labproje
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.list_of_users = new System.Windows.Forms.ListBox();
            this.txtuserchange = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.combouserchange = new System.Windows.Forms.ComboBox();
            this.btnuserchange = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtUserName
            // 
            this.txtUserName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtUserName.Location = new System.Drawing.Point(12, 47);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(293, 22);
            this.txtUserName.TabIndex = 0;
            this.txtUserName.TextChanged += new System.EventHandler(this.txtUserName_TextChanged);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Salmon;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Cascadia Code", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(293, 35);
            this.label1.TabIndex = 1;
            this.label1.Text = "Please enter username:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkSlateGray;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.Location = new System.Drawing.Point(12, 89);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 40);
            this.button1.TabIndex = 2;
            this.button1.Text = "ENTER";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // list_of_users
            // 
            this.list_of_users.BackColor = System.Drawing.Color.RosyBrown;
            this.list_of_users.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.list_of_users.FormattingEnabled = true;
            this.list_of_users.ItemHeight = 16;
            this.list_of_users.Location = new System.Drawing.Point(321, 47);
            this.list_of_users.Name = "list_of_users";
            this.list_of_users.Size = new System.Drawing.Size(161, 20);
            this.list_of_users.TabIndex = 3;
            // 
            // txtuserchange
            // 
            this.txtuserchange.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtuserchange.Location = new System.Drawing.Point(16, 322);
            this.txtuserchange.Name = "txtuserchange";
            this.txtuserchange.Size = new System.Drawing.Size(289, 22);
            this.txtuserchange.TabIndex = 4;
            this.txtuserchange.TextChanged += new System.EventHandler(this.txtuserchange_TextChanged);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Salmon;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Font = new System.Drawing.Font("Cascadia Code", 10.8F, System.Drawing.FontStyle.Italic);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(12, 278);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(500, 32);
            this.label2.TabIndex = 5;
            this.label2.Text = "Type the person whose to cahnge user type:";
            // 
            // combouserchange
            // 
            this.combouserchange.BackColor = System.Drawing.Color.RosyBrown;
            this.combouserchange.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.combouserchange.FormattingEnabled = true;
            this.combouserchange.Location = new System.Drawing.Point(321, 322);
            this.combouserchange.Name = "combouserchange";
            this.combouserchange.Size = new System.Drawing.Size(161, 24);
            this.combouserchange.TabIndex = 6;
            this.combouserchange.Text = "select new type";
            // 
            // btnuserchange
            // 
            this.btnuserchange.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btnuserchange.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnuserchange.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnuserchange.Location = new System.Drawing.Point(16, 364);
            this.btnuserchange.Name = "btnuserchange";
            this.btnuserchange.Size = new System.Drawing.Size(106, 38);
            this.btnuserchange.TabIndex = 7;
            this.btnuserchange.Text = "CHANGE";
            this.btnuserchange.UseVisualStyleBackColor = false;
            this.btnuserchange.Click += new System.EventHandler(this.btnuserchange_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(594, 450);
            this.Controls.Add(this.btnuserchange);
            this.Controls.Add(this.combouserchange);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtuserchange);
            this.Controls.Add(this.list_of_users);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtUserName);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox list_of_users;
        private System.Windows.Forms.TextBox txtuserchange;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox combouserchange;
        private System.Windows.Forms.Button btnuserchange;
    }
}

