﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static oop2labproje.Form1;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace oop2labproje
{
    public partial class Form1 : Form
    {
        private User_Manager manager;
        public Form1()
        {
            InitializeComponent(); 
            manager = new User_Manager();
        }
       
            public class User
        {
            public string Username { get; set; }
            public string UserType { get; set; }

            public User(string username)
            {
                Username = username;
                UserType = "User"; 
            }


        }



        class User_Manager {
        
          private List<User> users = new List<User>();

            public List<User> Users
            {
                get { return users; }
            }

            private bool adminCreate = false;   

            public void AddUser(string username)
            { 
                
                if (!adminCreate)
                {

                    User admin = new User(username);
                    admin.UserType = "Admin";
                    users.Add(admin);
                    MessageBox.Show("Admin created successfully.");
                  adminCreate = true;

                }                                      //DÜZELTİLECEK KISIM 


                else 
                {
                    
                    User newUser = new User(username);
                    users.Add(newUser);
                    MessageBox.Show("Normal user created successfully.");
                }
            }

            public void Change_User_Type(string username, string newType)
            {


                User user = users.Find(u => u.Username == username);
                if (user != null)
                {
                    user.UserType = newType;
                    MessageBox.Show($"User type for {username} changed to {newType}.");
                }
                else
                {
                    MessageBox.Show($"User '{username}' not found.");
                }


            } 
            public bool IsAdmin(string username)
        {
            User user = users.Find(u => u.Username == username && u.UserType == "Admin");
            return user != null;
        }

        }


        private void UpdateUserList()
        {
            list_of_users.Items.Clear();
            foreach (var user in manager.Users)
            {
                list_of_users.Items.Add($"{user.Username} - {user.UserType}");
            }
        }


       




        
        public void txtUserName_TextChanged(object sender, EventArgs e)
        {
            User user = new User(txtUserName.Text);

        }

        private void button1_Click(object sender, EventArgs e)
        {

            string username = txtUserName.Text;
            if (!string.IsNullOrEmpty(username))
            {
                manager.AddUser(username);
                txtUserName.Text = "";
                UpdateUserList();
            }
            else
            {
                MessageBox.Show("Please enter a username.");
            }
        }

        private void txtuserchange_TextChanged(object sender, EventArgs e)
        {

        }
       

        private void btnuserchange_Click(object sender, EventArgs e)
        {
            string username = txtuserchange.Text;
            string newType = combouserchange.SelectedItem?.ToString();

            if (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(newType))
            {
                using (var validationForm = new AdminValidationForm())
                {
                    if (validationForm.ShowDialog() == DialogResult.OK)
                    {
                        string adminUsername = validationForm.AdminUsername;

                        if (manager.IsAdmin(adminUsername))
                        {
                            manager.Change_User_Type(username, newType);
                            UpdateUserList();
                        }
                        else
                        {
                            MessageBox.Show("Invalid admin username.");
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please enter a username and select a user type.");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            combouserchange.Items.AddRange(new string[] { "Admin", "User", "Part-Time User" });
        }
    }
    }

