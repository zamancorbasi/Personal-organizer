﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace oopprojefinal
{
    public partial class Form3 : Form
    {
        private User_Manager manager;
        public Form3()
        {
            InitializeComponent();
            manager = new User_Manager();
        }

        public class User
        {
            public string Username { get; set; }
            public string UserType { get; set; }

            public User(string username)
            {
                Username = username;
                UserType = "User";
            }


        }



        class User_Manager
        {

            private List<User> users = new List<User>();

            public List<User> Users
            {
                get { return users; }
            }

            private bool adminCreate = false;

            public void AddUser(string username)
            {

                if (!adminCreate)
                {

                    User admin = new User(username);
                    admin.UserType = "Admin";
                    users.Add(admin);
                    MessageBox.Show("Admin created successfully.");
                    adminCreate = true;

                }                                      //DÜZELTİLECEK KISIM 


                else
                {

                    User newUser = new User(username);
                    users.Add(newUser);
                    MessageBox.Show("Normal user created successfully.");
                }
            }

            public void Change_User_Type(string username, string newType)
            {


                User user = users.Find(u => u.Username == username);
                if (user != null)
                {
                    user.UserType = newType;
                    MessageBox.Show($"User type for {username} changed to {newType}.");
                }
                else
                {
                    MessageBox.Show($"User '{username}' not found.");
                }


            }


        }


        private void UpdateUserList()
        {
            list_of_users.Items.Clear();
            foreach (var user in manager.Users)
            {
                list_of_users.Items.Add($"{user.Username} - {user.UserType}");
            }
        }








        public void txtUserName_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void txtuserchange_TextChanged(object sender, EventArgs e)
        {

        }


        private void btnuserchange_Click(object sender, EventArgs e)
        {
            string username = txtuserchange.Text;
            string newType = combouserchange.SelectedItem?.ToString();

            if (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(newType))
            {

                manager.Change_User_Type(username, newType);
                UpdateUserList();
            }
            else
            {
                MessageBox.Show("Please enter a username and select a user type.");
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            combouserchange.Items.AddRange(new string[] { "Admin", "User", "Part-Time User" });
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
