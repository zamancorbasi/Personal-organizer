﻿namespace oopprojefinal
{
    partial class Homepage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPersonalInformation = new System.Windows.Forms.Button();
            this.btnUserManangement = new System.Windows.Forms.Button();
            this.btnSalaryCalculator = new System.Windows.Forms.Button();
            this.btnNotebook = new System.Windows.Forms.Button();
            this.btnPhonebook = new System.Windows.Forms.Button();
            this.btnReminders = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnPersonalInformation
            // 
            this.btnPersonalInformation.Location = new System.Drawing.Point(12, 12);
            this.btnPersonalInformation.Name = "btnPersonalInformation";
            this.btnPersonalInformation.Size = new System.Drawing.Size(92, 48);
            this.btnPersonalInformation.TabIndex = 0;
            this.btnPersonalInformation.Text = "Personal Information";
            this.btnPersonalInformation.UseVisualStyleBackColor = true;
            this.btnPersonalInformation.Click += new System.EventHandler(this.btnPersonalInformation_Click);
            // 
            // btnUserManangement
            // 
            this.btnUserManangement.Location = new System.Drawing.Point(110, 12);
            this.btnUserManangement.Name = "btnUserManangement";
            this.btnUserManangement.Size = new System.Drawing.Size(92, 48);
            this.btnUserManangement.TabIndex = 1;
            this.btnUserManangement.Text = "User Manangement";
            this.btnUserManangement.UseVisualStyleBackColor = true;
            this.btnUserManangement.Click += new System.EventHandler(this.btnUserManangement_Click);
            // 
            // btnSalaryCalculator
            // 
            this.btnSalaryCalculator.Location = new System.Drawing.Point(12, 66);
            this.btnSalaryCalculator.Name = "btnSalaryCalculator";
            this.btnSalaryCalculator.Size = new System.Drawing.Size(92, 48);
            this.btnSalaryCalculator.TabIndex = 2;
            this.btnSalaryCalculator.Text = "Salary Calculator";
            this.btnSalaryCalculator.UseVisualStyleBackColor = true;
            this.btnSalaryCalculator.Click += new System.EventHandler(this.btnSalaryCalculator_Click);
            // 
            // btnNotebook
            // 
            this.btnNotebook.Location = new System.Drawing.Point(110, 66);
            this.btnNotebook.Name = "btnNotebook";
            this.btnNotebook.Size = new System.Drawing.Size(92, 48);
            this.btnNotebook.TabIndex = 3;
            this.btnNotebook.Text = "Notebook";
            this.btnNotebook.UseVisualStyleBackColor = true;
            this.btnNotebook.Click += new System.EventHandler(this.btnNotebook_Click);
            // 
            // btnPhonebook
            // 
            this.btnPhonebook.Location = new System.Drawing.Point(12, 120);
            this.btnPhonebook.Name = "btnPhonebook";
            this.btnPhonebook.Size = new System.Drawing.Size(92, 48);
            this.btnPhonebook.TabIndex = 4;
            this.btnPhonebook.Text = "Phonebook";
            this.btnPhonebook.UseVisualStyleBackColor = true;
            this.btnPhonebook.Click += new System.EventHandler(this.btnPhonebook_Click);
            // 
            // btnReminders
            // 
            this.btnReminders.Location = new System.Drawing.Point(110, 120);
            this.btnReminders.Name = "btnReminders";
            this.btnReminders.Size = new System.Drawing.Size(92, 48);
            this.btnReminders.TabIndex = 5;
            this.btnReminders.Text = "Reminders";
            this.btnReminders.UseVisualStyleBackColor = true;
            this.btnReminders.Click += new System.EventHandler(this.btnReminders_Click);
            // 
            // Homepage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(222, 189);
            this.Controls.Add(this.btnReminders);
            this.Controls.Add(this.btnPhonebook);
            this.Controls.Add(this.btnNotebook);
            this.Controls.Add(this.btnSalaryCalculator);
            this.Controls.Add(this.btnUserManangement);
            this.Controls.Add(this.btnPersonalInformation);
            this.Name = "Homepage";
            this.Text = "Homepage";
            this.Load += new System.EventHandler(this.Homepage_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnPersonalInformation;
        private System.Windows.Forms.Button btnUserManangement;
        private System.Windows.Forms.Button btnSalaryCalculator;
        private System.Windows.Forms.Button btnNotebook;
        private System.Windows.Forms.Button btnPhonebook;
        private System.Windows.Forms.Button btnReminders;
    }
}