﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopprojefinal
{
    //MERVE
    public class User
    {
        private string username;
        private string password;
        private string usertypes;
        private string name;
        private string surname;
        private string phoneNumber;
        private string address;
        private string email;
        private string photo;
        private string salary;

      
        public User(string username, string password, string usertypes, string name, string surname, string phoneNumber, string address, string email, string photo, string salary)
        {
            this.Username = username;
            this.Password = password;
            this.usertypes = usertypes;
            this.Name = name;
            this.Surname = surname;
            this.PhoneNumber = phoneNumber;
            this.Address = address;
            this.Email = email;
            this.Photo = photo;
            this.Salary = salary;
        }
        
        public User() { }
       
        public string Username { get => username; set => username = value; }
        public string Password { get => password; set => password = value; }
        public string Usertypes { get => usertypes; set => usertypes = value; }
        public string Name { get => name; set => name = value; }
        public string Surname { get => surname; set => surname = value; }
        public string PhoneNumber { get => phoneNumber; set => phoneNumber = value; }
        public string Address { get => address; set => address = value; }
        public string Email { get => email; set => email = value; }
        public string Photo { get => photo; set => photo = value; }
        public string Salary { get => salary; set => salary = value; }

        public string toString()
        {
            return username + "," + password + "," + usertypes + "," + name + "," + surname + "," + phoneNumber + "," + address + "," + email + "," + photo + "," + salary;
        }

        public bool IsMatching(string txtUsername,  string txtPassword)
        {
            return this.username.Equals(txtUsername) && this.password.Equals(txtPassword);
        }



    }
}
