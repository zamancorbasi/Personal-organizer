﻿using Personal_Organizer_Application;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using System.Xml.Linq;

namespace oopprojefinal
{
    public partial class Phonebook : Form
    {
        private string filePath = "phonebook.csv";

        public Phonebook()
        {
            InitializeComponent();
            LoadData();
            btnDelete.Click += btnDelete_Click;
            dataGridView1.SelectionChanged += dataGridView1_SelectionChanged;
            btnCreate.Click += btnCreate_Click;
            btnUpdate.Click += btnUpdate_Click;
        }

        private void LoadData()
        {
            if (File.Exists(filePath))
            {
                var lines = File.ReadAllLines(filePath);
                foreach (var line in lines)
                {
                    var parts = line.Split(',');
                    dataGridView1.Rows.Add(parts);
                }
            }
        }

        private void SaveData()
        {
            var lines = new List<string>();

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (!row.IsNewRow)
                {
                    var line = string.Format("{0},{1},{2},{3},{4},{5}",
                        row.Cells[0].Value,
                        row.Cells[1].Value,
                        row.Cells[2].Value,
                        row.Cells[3].Value,
                        row.Cells[4].Value,
                        row.Cells[5].Value);

                    lines.Add(line);
                }
            }

            File.WriteAllLines(filePath, lines);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }



        private void btnUpdate_Click(object sender, EventArgs e)
        {

            btnCreate.Text = "Update the record";
        }

        public void UpdateRecord()
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Seçilen satırın bilgilerini o anki textboxtakilerle değiştir
                var selectedRow = dataGridView1.SelectedRows[0];
                selectedRow.Cells[0].Value = txtName.Text;
                selectedRow.Cells[1].Value = txtSurname.Text;
                selectedRow.Cells[2].Value = txtNumber.Text;
                selectedRow.Cells[3].Value = txtAddress.Text;
                selectedRow.Cells[4].Value = txtDescription.Text;
                selectedRow.Cells[5].Value = txtEmail.Text;

                // Güncellenen veriyi dosyaya kaydet
                SaveData();

                // Input alanlarını temizle
                ClearInputs();
            }
        }


        public void CreateRecord()
        {
            MessageBox.Show("create edildi");
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {

            if (btnCreate.Text == "Create a record")
            {
                if (ValidateInputs())
                {
                    dataGridView1.Rows.Add(txtName.Text, txtSurname.Text, txtNumber.Text, txtAddress.Text, txtDescription.Text, txtEmail.Text);
                    SaveData();
                    ClearInputs();
                }
                //CreateRecord();
            }
            else if (btnCreate.Text == "Update the record")
            {
                UpdateRecord();
                btnCreate.Text = "Create a record";
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Seçili satırı sil
                dataGridView1.Rows.Remove(dataGridView1.SelectedRows[0]);

                // Verileri kaydet
                SaveData();

                // Giriş alanlarını temizle
                ClearInputs();
            }
            else
            {
                MessageBox.Show("Lütfen silmek için bir satır seçin.", "Silme Hatası", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(txtName.Text) ||
                string.IsNullOrWhiteSpace(txtSurname.Text) ||
                string.IsNullOrWhiteSpace(txtNumber.Text) ||
                string.IsNullOrWhiteSpace(txtAddress.Text) ||
                string.IsNullOrWhiteSpace(txtDescription.Text) ||
                string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                MessageBox.Show("All fields are required.");
                return false;
            }

            if (!Regex.IsMatch(txtNumber.Text, @"^\(\d{3}\) \d{3} \d{2} \d{2}$"))
            {
                MessageBox.Show("Invalid phone number format. Use (555) 555 55 55.");
                return false;
            }

            if (!Regex.IsMatch(txtEmail.Text, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                MessageBox.Show("Invalid email address.");
                return false;
            }

            return true;
        }

        private void ClearInputs()
        {
            txtName.Clear();
            txtSurname.Clear();
            txtNumber.Clear();
            txtAddress.Clear();
            txtDescription.Clear();
            txtEmail.Clear();
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {

            var selectedRow = dataGridView1.SelectedRows[0];
            txtName.Text = selectedRow.Cells[0].Value?.ToString();
            txtSurname.Text = selectedRow.Cells[1].Value?.ToString();
            txtNumber.Text = selectedRow.Cells[2].Value?.ToString();
            txtAddress.Text = selectedRow.Cells[3].Value?.ToString();
            txtDescription.Text = selectedRow.Cells[4].Value?.ToString();
            txtEmail.Text = selectedRow.Cells[5].Value?.ToString();


        }

        private void Phonebook_Load(object sender, EventArgs e)
        {

        }
    }

}
