﻿namespace oopprojefinal
{
    partial class SalaryCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbDeneyim = new System.Windows.Forms.ComboBox();
            this.cmbSehir = new System.Windows.Forms.ComboBox();
            this.cmbAkademi = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.lblSalary = new System.Windows.Forms.Label();
            this.lstYabanciDil = new System.Windows.Forms.ListBox();
            this.lstYoneticilik = new System.Windows.Forms.ListBox();
            this.lstAile = new System.Windows.Forms.ListBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cmbDeneyim
            // 
            this.cmbDeneyim.FormattingEnabled = true;
            this.cmbDeneyim.Items.AddRange(new object[] {
            "2-4 yıl",
            "5-9 yıl",
            "10-14 yıl",
            "15-20 yıl",
            "20 yıl üstü"});
            this.cmbDeneyim.Location = new System.Drawing.Point(12, 83);
            this.cmbDeneyim.Name = "cmbDeneyim";
            this.cmbDeneyim.Size = new System.Drawing.Size(218, 21);
            this.cmbDeneyim.TabIndex = 0;
            // 
            // cmbSehir
            // 
            this.cmbSehir.FormattingEnabled = true;
            this.cmbSehir.Items.AddRange(new object[] {
            "TR10: istanbul",
            "TR51: ankara",
            "TR31: izmir",
            "TR42: kocaeli,sakarya,düzce,bolu yalova",
            "TR21:edirne,kırklareli, tekirdağ",
            "TR90:trabzon,ordu,giresun,rize,artvin,gümüşhane",
            "TR41:bursa,eskişehir,bilecik",
            "TR32:aydın,denizli,muğla",
            "TR62:adana,mersin",
            "TR22:balıkesir,çanakkale",
            "TR61:antalya,ısparta,burdur",
            "Diğer iller"});
            this.cmbSehir.Location = new System.Drawing.Point(12, 128);
            this.cmbSehir.Name = "cmbSehir";
            this.cmbSehir.Size = new System.Drawing.Size(218, 21);
            this.cmbSehir.TabIndex = 1;
            // 
            // cmbAkademi
            // 
            this.cmbAkademi.FormattingEnabled = true;
            this.cmbAkademi.Items.AddRange(new object[] {
            "yüksek lisans",
            "doktora",
            "doçentlik",
            "alakasız yüksek lisans",
            "alakasız doktora/doçentlik"});
            this.cmbAkademi.Location = new System.Drawing.Point(12, 172);
            this.cmbAkademi.Name = "cmbAkademi";
            this.cmbAkademi.Size = new System.Drawing.Size(218, 21);
            this.cmbAkademi.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "yasanılan il";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 154);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "akademik derece";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 196);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "yabanci dil bilgisi";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 275);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "yöneticilik görevi";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 387);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "aile durumu";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(155, 474);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 12;
            this.button1.Text = "hesapla";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblSalary
            // 
            this.lblSalary.AutoSize = true;
            this.lblSalary.Location = new System.Drawing.Point(29, 361);
            this.lblSalary.Name = "lblSalary";
            this.lblSalary.Size = new System.Drawing.Size(0, 13);
            this.lblSalary.TabIndex = 14;
            // 
            // lstYabanciDil
            // 
            this.lstYabanciDil.FormattingEnabled = true;
            this.lstYabanciDil.Items.AddRange(new object[] {
            "belgelendirilmiş ingilizce bilgisi",
            "ingilizce eğitim veren okul mezuniyeti",
            "belgelendirilmiş diğer yabancı dil bilgisi"});
            this.lstYabanciDil.Location = new System.Drawing.Point(12, 212);
            this.lstYabanciDil.Name = "lstYabanciDil";
            this.lstYabanciDil.ScrollAlwaysVisible = true;
            this.lstYabanciDil.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lstYabanciDil.Size = new System.Drawing.Size(218, 56);
            this.lstYabanciDil.TabIndex = 15;
            // 
            // lstYoneticilik
            // 
            this.lstYoneticilik.FormattingEnabled = true;
            this.lstYoneticilik.Items.AddRange(new object[] {
            "Takım Lideri/Grup Yöneticisi/Teknik Yönetici/Yazılım Mimarı",
            "Proje Yöneticisi ",
            "Direktör/Projeler Yöneticisi ",
            "CTO/Genel Müdür ",
            "Bilgi İşlem Sorumlusu/Müdürü  (Bilgi İşlem biriminde en çok 5 bilişim personeli v" +
                "arsa) ",
            "Bilgi İşlem Sorumlusu/Müdürü  (Bilgi İşlem biriminde 5\'ten çok bilişim personeli " +
                "varsa) "});
            this.lstYoneticilik.Location = new System.Drawing.Point(12, 302);
            this.lstYoneticilik.Name = "lstYoneticilik";
            this.lstYoneticilik.ScrollAlwaysVisible = true;
            this.lstYoneticilik.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lstYoneticilik.Size = new System.Drawing.Size(218, 82);
            this.lstYoneticilik.TabIndex = 16;
            // 
            // lstAile
            // 
            this.lstAile.FormattingEnabled = true;
            this.lstAile.Items.AddRange(new object[] {
            "Evli ve eşi çalışmıyor ",
            "0-6 yaş arası çocuk  ",
            "7-18 yaş arası çocuk  ",
            "18 yaş üstü çocuk (Üniversite lisans/ön lisans öğrencisi olmak koşuluyla)  "});
            this.lstAile.Location = new System.Drawing.Point(12, 403);
            this.lstAile.Name = "lstAile";
            this.lstAile.ScrollAlwaysVisible = true;
            this.lstAile.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lstAile.Size = new System.Drawing.Size(218, 56);
            this.lstAile.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 525);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 13);
            this.label7.TabIndex = 18;
            this.label7.Text = "Maaşınız:";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 68);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 13);
            this.label8.TabIndex = 20;
            this.label8.Text = "deneyim";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(15, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(121, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 13);
            this.label1.TabIndex = 22;
            this.label1.Text = "brüt maaşınız";
            // 
            // SalaryCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(341, 599);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lstAile);
            this.Controls.Add(this.lstYoneticilik);
            this.Controls.Add(this.lstYabanciDil);
            this.Controls.Add(this.lblSalary);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmbAkademi);
            this.Controls.Add(this.cmbSehir);
            this.Controls.Add(this.cmbDeneyim);
            this.Name = "SalaryCalculator";
            this.Text = "SalaryCalculator";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SalaryCalculator_FormClosing);
            this.Load += new System.EventHandler(this.SalaryCalculator_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbDeneyim;
        private System.Windows.Forms.ComboBox cmbSehir;
        private System.Windows.Forms.ComboBox cmbAkademi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblSalary;
        private System.Windows.Forms.ListBox lstYabanciDil;
        private System.Windows.Forms.ListBox lstYoneticilik;
        private System.Windows.Forms.ListBox lstAile;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
    }
}