﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace oopprojefinal
{
    public partial class Homepage : Form
    {
        User user = LoginedUser.getInstance().UserGetSet;
        public Homepage()
        {
            InitializeComponent();
        }

        private void btnUserManangement_Click(object sender, EventArgs e)
        {
            if(user.Usertypes == "admin")
            {
                MessageBox.Show("admin girebilir");
                Form3 form3 = new Form3();
                form3.Show();

            }
            else
            {
                MessageBox.Show("admin olmayanlar giremez");
            }
        }

        private void btnPersonalInformation_Click(object sender, EventArgs e)
        {

            PersonalInfo personalInfo = new PersonalInfo();
            personalInfo.Show();
            this.Hide();
            
        }

        private void Homepage_Load(object sender, EventArgs e)
        {
            
        }

        private void btnSalaryCalculator_Click(object sender, EventArgs e)
        {
            SalaryCalculator salaryCalculator = new SalaryCalculator();
            salaryCalculator.Show();
            this.Hide();
        }

        private void btnPhonebook_Click(object sender, EventArgs e)
        {
            Phonebook fr = new Phonebook();
            fr.Show();
            this.Hide();
        }

        private void btnNotebook_Click(object sender, EventArgs e)
        {
            Notebook notebook = new Notebook();
            notebook.Show();
            this.Hide();
        }

        private void btnReminders_Click(object sender, EventArgs e)
        {

        }
    }
}
