﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopprojefinal
{
    public class PhoneRecords
    {
        private string user;
        private string name;
        private string surname;
        private string number;
        private string address;
        private string description;
        private string email;
        public PhoneRecords(string user, string name, string surname, string number, string address, string description, string email)
        {
            this.user = user;
            this.name = name;
            this.surname = surname;
            this.number = number;
            this.address = address;
            this.description = description;
            this.email = email;
        }

        //get set fonksiyonları değişkenler private olduğu için
        /*public string Ad
        {
            get { return ad; } // Get fonksiyonu
            set { ad = value; } // Set fonksiyonu
        }*/

        public string User { get => user; set => user = value; }
        public string Name { get => name; set => name = value; }
        public string Surname { get => surname; set => surname = value; }
        public string Number { get => number; set => number = value; }
        public string Address { get => address; set => address = value; }
        public string Description { get => description; set => description = value; }
        public string Mail { get => email; set => email = value; }

        public string toString()
        {
            return user + "," + name + "," + surname + "," + number + "," + address + "," + description + "," + email;
        }
    }
}
