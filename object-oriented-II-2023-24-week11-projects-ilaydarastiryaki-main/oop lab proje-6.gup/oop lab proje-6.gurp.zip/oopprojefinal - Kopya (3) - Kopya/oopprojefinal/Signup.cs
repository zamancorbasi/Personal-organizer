﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace oopprojefinal
{
    public partial class Signup : Form
    {
        private string photoBase64;

        public Signup()
        {
            InitializeComponent();
        }

        private void Sigup_Load(object sender, EventArgs e)
        {
            txtName.Text = "";
            txtPassword.Text = "";
            txtName.Text = "";
            txtSurname.Text = "";
            txtNumber.Text = "";
            txtAddress.Text = "";
            txtEmail.Text = "";
            lblPath.Text = "";
            
        }
        private bool ValidateInputs()
        {
            string emailPattern = @"^\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b";
            string phonePattern = @"^\(\d{3}\) \d{3} \d{2} \d{2}$";

            if (!Regex.IsMatch(txtEmail.Text, emailPattern))
            {
                MessageBox.Show("Invalid email format.");
                return false;
            }

            if (!Regex.IsMatch(txtNumber.Text, phonePattern))
            {
                MessageBox.Show("Invalid phone format.");
                return false;
            }

            if (!IsValidPassword(txtPassword.Text))
            {
                MessageBox.Show("Invalid password format. Password must be at least 8 characters long, contain at least one uppercase letter, one lowercase letter, and one digit.");
                return false;
            }

            return true;
        }
        private bool IsValidPassword(string password)
        {
            // Şifrenin en az 8 karakter uzunluğunda olması, en az bir büyük harf, bir küçük harf ve bir rakam içermesi gerekmektedir
            if (password.Length < 8)
                return false;

            bool hasUpperChar = false, hasLowerChar = false, hasDecimalDigit = false;

            foreach (char c in password)
            {
                if (char.IsUpper(c)) hasUpperChar = true;
                else if (char.IsLower(c)) hasLowerChar = true;
                else if (char.IsDigit(c)) hasDecimalDigit = true;
            }

            return hasUpperChar && hasLowerChar && hasDecimalDigit;
        }

        //merve


        bool adminCreate = false;
        public void AddUser()
        {

            if (!adminCreate)
            {
                User admin = new User(txtUsername.Text, txtPassword.Text, "admin", txtName.Text, txtSurname.Text, txtNumber.Text, txtAddress.Text, txtEmail.Text, photoBase64, "5000");
                Form1.userList.Add(admin);
                MessageBox.Show("Admin created successfully.");
                adminCreate = true;

            }                                      
            else
            {

                User newUser = new User(txtUsername.Text, txtPassword.Text, "user", txtName.Text, txtSurname.Text, txtNumber.Text, txtAddress.Text, txtEmail.Text, photoBase64, "5000");
                Form1.userList.Add(newUser);
                MessageBox.Show("Normal user created successfully.");
            }
        }
        private void btnSignup_Click(object sender, EventArgs e)
        {
            
            for (int i = 0; i < Form1.userList.Count(); i++)
            {
                if (txtUsername.Text == Form1.userList[i].Username)
                {
                    MessageBox.Show("User already exists!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    break;
                }
                else if (txtUsername.Text == "" || txtPassword.Text == "" || txtName.Text == "" || txtSurname.Text == "" || txtNumber.Text == "" || txtAddress.Text == "" || txtEmail.Text == "" || photoBase64 == "")
                {
                    MessageBox.Show("Please fill in the blanks!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    break;
                }
            }
            if (ValidateInputs())
            {
                AddUser();
            }

            




        }

        

        private void btnPhoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Image Files (*.png; *.jpg; *.bmp)|*.png;*.jpg;*.bmp"
            };
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(openFileDialog.FileName);

                // Fotoğrafı 'Uploads' klasörüne kaydetme
                string uploadsDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Uploads");
                if (!Directory.Exists(uploadsDirectory))
                {
                    Directory.CreateDirectory(uploadsDirectory);
                }

                string fileName = Path.GetFileName(openFileDialog.FileName);
                string filePath = Path.Combine(uploadsDirectory, fileName);

                File.Copy(openFileDialog.FileName, filePath, true);


                // Dosya yolunu saklama
                photoBase64 = filePath;
            }
        }

        private void txtNumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void Signup_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form1 form1 = Form1.Form1Instance;
            form1.Show();
        }
    }
}
