﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace oopprojefinal
{
    public partial class Form1 : Form
    {
        public static List<User> userList = new List<User>();
        public static string path = "mydb.csv";
        public static Form1 Form1Instance;
      
        Signup signup = new Signup();
        public Form1()
        {
            InitializeComponent();
            Form1Instance = this;
            Util.LoadCsv(userList, path);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtUsername.Text = "";
            txtPassword.Text = "";
            
            //Notebook notebook = new Notebook();
            //notebook.Show();
            //Phonebook phonebook = new Phonebook();
            //phonebook.Show();
            //SalaryCalculator salaryCalculator = new SalaryCalculator();
            //salaryCalculator.Show();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            for (int i = 0; i < userList.Count; i++)
            {
                User user = userList[i];
                if (user.IsMatching(username, password) == true)
                {
                    LoginedUser.getInstance().UserGetSet = user;
                    lblLogin.BackColor = Color.Green;
                    lblLogin.Text = "successful login";
                    lblLogin.Visible = true;

                    this.Hide();
                    Homepage homepage = new Homepage();
                    homepage.ShowDialog();
                

                    return;
                }
            }
            lblLogin.BackColor = Color.Red;
            lblLogin.Text = "failed login";
            lblLogin.Visible = true;
            txtUsername.Text = "";
            txtPassword.Text = "";

            /*for (int i = 0; i < userList.Count; i++)
            {
                User user = userList[i];
                if(user.IsMatching(username, password))
                {
                    MessageBox.Show("şifredoğru");
                }
                else
                {
                    MessageBox.Show("şifre yanlış");
                }
                //eğer username ve password uyuyorsa lblLogin=succesfull giriş 
                //uyuşmuyorsa lblLogin = failed login
            }*/
        }

        private void btnSignup_Click(object sender, EventArgs e)
        {
            this.Hide();
            signup.ShowDialog();
            if (signup.IsDisposed)
            {
                this.Show();
            }
            
        }

        public void UpdateUserList()
        {
            list_of_users.Items.Clear();
            foreach (var user in userList)
            {
                list_of_users.Items.Add($"{user.Username} - {user.Password}-{user.Usertypes}");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UpdateUserList();
        }
    }
}
