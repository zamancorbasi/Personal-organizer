﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace oopprojefinal
{
    public partial class SalaryCalculator : Form
    {
        double katsayi = 0.0;
        User user = LoginedUser.getInstance().UserGetSet;
        public SalaryCalculator()
        {
            InitializeComponent();
        }

        private void SalaryCalculator_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double maas = hesapla();
            user.Salary = maas.ToString();
        }

        public double hesapla()
        {

            try { 
          
                //MessageBox.Show(katsayi.ToString());

                if (cmbDeneyim.SelectedItem.ToString() == "2-4 yıl")
                {
                    katsayi = katsayi + 0.60;
                }
                else if (cmbDeneyim.SelectedItem.ToString() == "5-9 yıl")
                {
                    katsayi = katsayi + 1.00;
                }
                else if (cmbDeneyim.SelectedItem.ToString() == "10-14 yıl")
                {
                    katsayi = katsayi + 1.20;
                }
                else if (cmbDeneyim.SelectedItem.ToString() == "15-20 yıl")
                {
                    katsayi = katsayi + 1.35;
                }
                else if (cmbDeneyim.SelectedItem.ToString() == "20 yıl üstü")
                {
                    katsayi = katsayi + 1.50;
                }

                //MessageBox.Show("deneyim"+katsayi.ToString());

                if (cmbSehir.SelectedIndex == 0)
                {
                    katsayi = katsayi + 0.30;
                }
                else if (cmbSehir.SelectedIndex == 1 || cmbSehir.SelectedIndex == 2)
                {
                    katsayi = katsayi + 0.20;
                }
                else if (cmbSehir.SelectedIndex == 3 || cmbSehir.SelectedIndex == 4)
                {
                    katsayi = katsayi + 0.10;
                }
                else if (cmbSehir.SelectedIndex == 5 || cmbSehir.SelectedIndex == 6 || cmbSehir.SelectedIndex == 7 || cmbSehir.SelectedIndex == 8 || cmbSehir.SelectedIndex == 9 || cmbSehir.SelectedIndex == 10)
                {
                    katsayi = katsayi + 0.05;
                }
                else if (cmbSehir.SelectedItem.ToString() == "Diğer iller")
                {
                    katsayi = katsayi + 0.00;
                }

                //MessageBox.Show("sehir" + katsayi.ToString());
                if (cmbAkademi.SelectedIndex == 0)
                {
                    katsayi = katsayi + 0.10;
                }
                else if (cmbAkademi.SelectedIndex == 1)
                {
                    katsayi = katsayi + 0.30;
                }
                else if (cmbAkademi.SelectedIndex == 2)
                {
                    katsayi = katsayi + 0.35;
                }
                else if (cmbAkademi.SelectedIndex == 3)
                {
                    katsayi = katsayi + 0.05;
                }
                else if (cmbAkademi.SelectedIndex == 4)
                {
                    katsayi = katsayi + 0.15;
                }
                //MessageBox.Show("akademi" + katsayi.ToString());

                if (lstYabanciDil.SelectedIndex == 0)
                {
                    katsayi = katsayi + 0.20;
                }

                if (lstYabanciDil.SelectedIndex == 1)
                {
                    katsayi = katsayi + 0.20;
                }

                if (lstYabanciDil.SelectedIndex == 2)
                {
                    katsayi = katsayi + 0.05;
                }
                //MessageBox.Show("dil" + katsayi.ToString());

                if (lstYoneticilik.SelectedIndex == 0)
                {
                    katsayi = katsayi + 0.50;
                }
                if (lstYoneticilik.SelectedIndex == 1)
                {
                    katsayi = katsayi + 0.75;
                }
                if (lstYoneticilik.SelectedIndex == 2)
                {
                    katsayi = katsayi + 0.85;
                }
                if (lstYoneticilik.SelectedIndex == 3)
                {
                    katsayi = katsayi + 1.00;
                }
                if (lstYoneticilik.SelectedIndex == 4)
                {
                    katsayi = katsayi + 0.40;
                }
                if (lstYoneticilik.SelectedIndex == 5)
                {
                    katsayi = katsayi + 0.60;
                }
                //MessageBox.Show("yööneticilik" + katsayi.ToString());

                double maas = Double.Parse(textBox1.Text);
                MessageBox.Show("maas" + maas);

                maas = (2 * maas) * (katsayi + 1);
                MessageBox.Show("maas" + maas);
                label7.Text = label7.Text + maas.ToString();

                if (user.Usertypes == "part-time user")
                {
                    maas = maas / 2.0;
                }

                lblSalary.Text += maas.ToString();
            }
            catch (Exception)
            {
                MessageBox.Show("boşluklarını doldurunuz");
            }
            /*double maas = Double.Parse(textBox1.Text);
            
            maas = (2 * maas) * (katsayi + 1);
            lblSalary.Text += maas.ToString();

            if(user.Usertypes == "part-time user")
            {
                maas = maas / 2.0;
            }
            return maas;*/
            return 0;
        }

        private void SalaryCalculator_FormClosing(object sender, FormClosingEventArgs e)
        {
            Homepage fr = new Homepage();
            fr.Show();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
