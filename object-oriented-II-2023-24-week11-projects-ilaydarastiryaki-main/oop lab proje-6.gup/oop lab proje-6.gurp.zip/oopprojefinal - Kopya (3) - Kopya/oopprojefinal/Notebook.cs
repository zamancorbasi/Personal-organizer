﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO; // Bu satırı ekleyin
namespace oopprojefinal
{
    public partial class Notebook : Form
    {
        private string filePath = "notes.csv";
        private List<string> notes = new List<string>();

        public Notebook()
        {
            InitializeComponent();
            LoadNotes();
        }

        // Notları yükleme
        private void LoadNotes()
        {
            if (File.Exists(filePath))
            {
                notes = File.ReadAllLines(filePath).ToList();
            }
            dgvNotes.DataSource = notes.Select(n => new { Note = n.Replace("|", " ") }).ToList();
        }

        // Notları kaydetme
        private void SaveNotes()
        {
            File.WriteAllLines(filePath, notes);
        }


    

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            if (dgvNotes.SelectedRows.Count > 0 && !string.IsNullOrWhiteSpace(txtNote.Text))
            {
                int index = dgvNotes.SelectedRows[0].Index;
                notes[index] = txtNote.Text;
                SaveNotes();
                LoadNotes();
                txtNote.Clear();
            }
            else
            {
                MessageBox.Show("Lütfen güncellenecek notu seçin ve yeni notu girin.");
            }
        }

      

        private void btnAdd_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtNote.Text))
            {
                notes.Add(txtNote.Text.Replace(Environment.NewLine, "|"));
                SaveNotes();
                LoadNotes();
                txtNote.Clear();
            }
            else
            {
                MessageBox.Show("Lütfen bir not girin.");
            }
        }

        private void btnUpdate_Click_1(object sender, EventArgs e)
        {
            if (dgvNotes.SelectedRows.Count > 0 && !string.IsNullOrWhiteSpace(txtNote.Text))
            {
                int index = dgvNotes.SelectedRows[0].Index;
                notes[index] = txtNote.Text.Replace(Environment.NewLine, "|");
                SaveNotes();
                LoadNotes();
                txtNote.Clear();
            }
            else
            {
                MessageBox.Show("Lütfen güncellenecek notu seçin ve yeni notu girin.");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if(dgvNotes.SelectedRows.Count > 0)
            {
                int index = dgvNotes.SelectedRows[0].Index;
                notes.RemoveAt(index);
                SaveNotes();
                LoadNotes();
                txtNote.Clear();
            }
            else
            {
                MessageBox.Show("Lütfen silinecek notu seçin.");
            }
        }

        private void dgvNotes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                object cellValue = dgvNotes.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;

                if (cellValue != null)
                {
                    txtNote.Text = cellValue.ToString().Replace(" ", Environment.NewLine).Replace("|", Environment.NewLine);
                }
                else
                {
                    txtNote.Clear();
                }
            }
        }
        private void dgvNotes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Notebook_Load(object sender, EventArgs e)
        {

        }
    }
}
