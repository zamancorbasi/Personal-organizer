﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace oopprojefinal
{
    
    public partial class PersonalInfo : Form
    {
        
        private string photoBase64;

        User user = LoginedUser.getInstance().UserGetSet;

        public string path = "personal_info.csv";

        Stack<string[]> undoStack = new Stack<string[]>();
        Stack<string[]> redoStack = new Stack<string[]>();
        public PersonalInfo()
        {
            InitializeComponent();
            this.KeyPreview = true; // KeyPreview özelliğini true olarak ayarla
            this.KeyDown += new KeyEventHandler(Form1_KeyDown);
        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.Z)
            {
                Undo();
            }
            else if (e.Control && e.KeyCode == Keys.Y)
            {
                Redo();
            }
        }

        private void PersonalInfo_Load(object sender, EventArgs e)
        {
            string projectDirectory = AppDomain.CurrentDomain.BaseDirectory;
            string filePath = Path.Combine(projectDirectory, "personal_info.csv");
            Util.LoadCsv(Form1.userList, @"personal_info.csv");


            txtUsername.Text = user.Username;
            txtUserType.Text = user.Usertypes;
            txtName.Text = user.Name;
            txtSurname.Text = user.Surname;
            txtNumber.Text = user.PhoneNumber;
            
            if (user.Address.Contains("#"))
            {
                user.Address = user.Address.Replace("#", ",");
            }
            txtAddress.Text = user.Address;
            txtEmail.Text = user.Email;
            string base64 = Util.ImageToBase64(user.Photo);
            pictureBox.Image = Util.Base64ToImage(base64);
            txtPassword.Text = user.Password;
        }


        


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            User user = LoginedUser.getInstance().UserGetSet;
            if (!ValidateInputs())
            {
                return;
            }

            Util.LoadCsv(Form1.userList, path);

            SaveStateToUndoStack();

            var data = new
            {
                Username = txtUsername.Text,
                Name = txtName.Text,
                Surname = txtSurname.Text,
                Phone = txtNumber.Text,
                Address = txtAddress.Text,
                Email = txtEmail.Text,
                Password = txtPassword.Text,
                Photo = photoBase64 // Fotoğrafın dosya yolu
            };

            user.Username = txtUsername.Text;
            user.Name = txtName.Text;
            user.Surname = txtSurname.Text;
            user.Address = txtAddress.Text;
            user.Email = txtEmail.Text;
            user.PhoneNumber = txtNumber.Text;

            string projectDirectory = AppDomain.CurrentDomain.BaseDirectory;
            string filePath = Path.Combine(projectDirectory, "personal_info.csv");

            try
            {
                using (StreamWriter sw = new StreamWriter(filePath))
                {
                    sw.WriteLine("Name,Surname,Phone,Address,Email,Password,Photo");
                    sw.WriteLine($"{data.Name},{data.Surname},{data.Phone},{data.Address},{data.Email},{data.Password},{data.Photo}");
                }
                MessageBox.Show("Saved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while saving: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        ///UMAY 
        private bool ValidateInputs()
        {
            string emailPattern = @"^\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b";
            string phonePattern = @"^\(\d{3}\) \d{3} \d{2} \d{2}$";

            if (!Regex.IsMatch(txtEmail.Text, emailPattern))
            {
                MessageBox.Show("Invalid email format.");
                return false;
            }

            if (!Regex.IsMatch(txtNumber.Text, phonePattern))
            {
                MessageBox.Show("Invalid phone format.");
                return false;
            }

            if (!IsValidPassword(txtPassword.Text))
            {
                MessageBox.Show("Invalid password format. Password must be at least 8 characters long, contain at least one uppercase letter, one lowercase letter, and one digit.");
                return false;
            }

            return true;
        }
        private bool IsValidPassword(string password)
        {
            // Şifrenin en az 8 karakter uzunluğunda olması, en az bir büyük harf, bir küçük harf ve bir rakam içermesi gerekmektedir
            if (password.Length < 8)
                return false;

            bool hasUpperChar = false, hasLowerChar = false, hasDecimalDigit = false;

            foreach (char c in password)
            {
                if (char.IsUpper(c)) hasUpperChar = true;
                else if (char.IsLower(c)) hasLowerChar = true;
                else if (char.IsDigit(c)) hasDecimalDigit = true;
            }

            return hasUpperChar && hasLowerChar && hasDecimalDigit;
        }

        private void btnUploadPhoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Image Files (*.png; *.jpg; *.bmp)|*.png;*.jpg;*.bmp"
            };
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                pictureBox.Image = Image.FromFile(openFileDialog.FileName);

                // Fotoğrafı 'Uploads' klasörüne kaydetme
                string uploadsDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Uploads");
                if (!Directory.Exists(uploadsDirectory))
                {
                    Directory.CreateDirectory(uploadsDirectory);
                }

                string fileName = Path.GetFileName(openFileDialog.FileName);
                string filePath = Path.Combine(uploadsDirectory, fileName);

                File.Copy(openFileDialog.FileName, filePath, true);

                // Dosya yolunu saklama
                photoBase64 = filePath;
            }
        }
       

        private void SaveStateToUndoStack() // mevcut durumu undo yığınına kaydet
        {
            string[] currentState = new string[]
            {
                txtName.Text,
                txtUsername.Text,
                txtSurname.Text,
                txtNumber.Text,
                txtAddress.Text,
                txtEmail.Text,
                txtPassword.Text,
                photoBase64
            };
            undoStack.Push(currentState);
            redoStack.Clear(); // Yeni bir işlem yapıldığında redo yığını temizlenir
        }

        private void Undo()
        {
            if (undoStack.Count > 0)
            {
                string[] currentState = new string[]
                {
                    txtUsername.Text,
                    txtName.Text,
                    txtSurname.Text,
                    txtNumber.Text,
                    txtAddress.Text,
                    txtEmail.Text,
                    txtPassword.Text,
                    photoBase64
                };

                redoStack.Push(currentState);

                string[] previousState = undoStack.Pop();
                txtUsername.Text = previousState[0];
                txtName.Text = previousState[1];
                txtSurname.Text = previousState[2];
                txtNumber.Text = previousState[3];
                txtAddress.Text = previousState[4];
                txtEmail.Text = previousState[5];
                txtPassword.Text = previousState[6];
                string base64 = Util.ImageToBase64(user.Photo);
                pictureBox.Image = Util.Base64ToImage(previousState[7]);

                // Debug mesajı

            }
        }

        private void Redo()
        {
            if (redoStack.Count > 0)
            {
                string[] currentState = new string[]
                {
                    txtUsername.Text,
                    txtName.Text,
                    txtSurname.Text,
                    txtNumber.Text,
                    txtAddress.Text,
                    txtEmail.Text,
                    txtPassword.Text,
                    photoBase64
                };
                undoStack.Push(currentState);

                string[] nextState = redoStack.Pop();
                txtUsername.Text = nextState[0];
                txtName.Text = nextState[1];
                txtSurname.Text = nextState[2];
                txtNumber.Text = nextState[3];
                txtAddress.Text = nextState[4];
                txtEmail.Text = nextState[5];
                txtPassword.Text = nextState[6];
                string base64 = Util.ImageToBase64(user.Photo);
                pictureBox.Image = Util.Base64ToImage(nextState[7]);
                
            }
        }

        private void btnSifreyiDegistir_Click(object sender, EventArgs e)
        {
            labelYeniSifre.Visible = true;
            labelYeniSifreOnay.Visible = true;
            txtYeniSifre.Visible = true;
            txtYeniSifreyiOnayla.Visible = true;
            btnOnayla.Visible = true;
        }

        private void btnOnayla_Click(object sender, EventArgs e)
        {
            string newPassword = txtYeniSifre.Text;
            string confirmPassword = txtYeniSifreyiOnayla.Text;

            if (newPassword != confirmPassword)
            {
                MessageBox.Show("Passwords do not match. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!IsValidPassword(newPassword))
            {
                MessageBox.Show("Invalid password format. Password must be at least 8 characters long, contain at least one uppercase letter, one lowercase letter, and one digit.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            txtPassword.Text = newPassword;

            // Update the CSV file

            string projectDirectory = AppDomain.CurrentDomain.BaseDirectory;
            string filePath = Path.Combine(projectDirectory, "personal_info.csv");

            try
            {
                using (StreamWriter sw = new StreamWriter(filePath))
                {
                    sw.WriteLine("Name,Surname,Phone,Address,Email,Password,Photo");
                    sw.WriteLine($"{txtName.Text},{txtSurname.Text},{txtNumber.Text},{txtAddress.Text},{txtEmail.Text},{txtPassword.Text},{photoBase64}");
                }
                MessageBox.Show("Your password has been changed and saved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while saving: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            labelYeniSifre.Visible = false;
            labelYeniSifreOnay.Visible = false;
            txtYeniSifre.Visible = false;
            txtYeniSifreyiOnayla.Visible = false;
            btnOnayla.Visible = false;
        
        }

        private void PersonalInfo_FormClosing(object sender, FormClosingEventArgs e)
        {
            Homepage fr = new Homepage();
            fr.Show();
        }
    }
}
