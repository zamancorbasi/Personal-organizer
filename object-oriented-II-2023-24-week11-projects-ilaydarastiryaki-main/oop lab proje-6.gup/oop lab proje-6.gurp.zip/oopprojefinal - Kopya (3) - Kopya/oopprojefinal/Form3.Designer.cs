﻿namespace oopprojefinal
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.list_of_users = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.btnuserchange = new System.Windows.Forms.Button();
            this.combouserchange = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtuserchange = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // list_of_users
            // 
            this.list_of_users.BackColor = System.Drawing.Color.RosyBrown;
            this.list_of_users.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.list_of_users.FormattingEnabled = true;
            this.list_of_users.Location = new System.Drawing.Point(233, 40);
            this.list_of_users.Margin = new System.Windows.Forms.Padding(2);
            this.list_of_users.Name = "list_of_users";
            this.list_of_users.Size = new System.Drawing.Size(122, 17);
            this.list_of_users.TabIndex = 22;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkSlateGray;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.Location = new System.Drawing.Point(242, 325);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(80, 32);
            this.button1.TabIndex = 21;
            this.button1.Text = "ENTER";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Visible = false;
            // 
            // txtUserName
            // 
            this.txtUserName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtUserName.Location = new System.Drawing.Point(8, 338);
            this.txtUserName.Margin = new System.Windows.Forms.Padding(2);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(221, 20);
            this.txtUserName.TabIndex = 20;
            this.txtUserName.Visible = false;
            // 
            // btnuserchange
            // 
            this.btnuserchange.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btnuserchange.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnuserchange.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnuserchange.Location = new System.Drawing.Point(11, 74);
            this.btnuserchange.Margin = new System.Windows.Forms.Padding(2);
            this.btnuserchange.Name = "btnuserchange";
            this.btnuserchange.Size = new System.Drawing.Size(80, 31);
            this.btnuserchange.TabIndex = 19;
            this.btnuserchange.Text = "CHANGE";
            this.btnuserchange.UseVisualStyleBackColor = false;
            // 
            // combouserchange
            // 
            this.combouserchange.BackColor = System.Drawing.Color.RosyBrown;
            this.combouserchange.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.combouserchange.FormattingEnabled = true;
            this.combouserchange.Location = new System.Drawing.Point(233, 74);
            this.combouserchange.Margin = new System.Windows.Forms.Padding(2);
            this.combouserchange.Name = "combouserchange";
            this.combouserchange.Size = new System.Drawing.Size(122, 21);
            this.combouserchange.TabIndex = 18;
            this.combouserchange.Text = "select new type";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Salmon;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Font = new System.Drawing.Font("Cascadia Code", 10.8F, System.Drawing.FontStyle.Italic);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(8, 9);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(375, 26);
            this.label2.TabIndex = 17;
            this.label2.Text = "Type the person whose to cahnge user type:";
            // 
            // txtuserchange
            // 
            this.txtuserchange.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtuserchange.Location = new System.Drawing.Point(11, 40);
            this.txtuserchange.Margin = new System.Windows.Forms.Padding(2);
            this.txtuserchange.Name = "txtuserchange";
            this.txtuserchange.Size = new System.Drawing.Size(218, 20);
            this.txtuserchange.TabIndex = 16;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(412, 450);
            this.Controls.Add(this.list_of_users);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtUserName);
            this.Controls.Add(this.btnuserchange);
            this.Controls.Add(this.combouserchange);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtuserchange);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox list_of_users;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.Button btnuserchange;
        private System.Windows.Forms.ComboBox combouserchange;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtuserchange;
    }
}