﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;

//excel dosyası klasörde bin\debug\personal-information path'i altındadır.,
//Umay Ece Mantar 152120221127

namespace personalinformation
{
    public partial class PersonalInfo : Form
    {
        private string photoBase64;
        public PersonalInfo()
        {
            InitializeComponent();
            this.KeyPreview = true; // KeyPreview özelliğini true olarak ayarla
            this.KeyDown += new KeyEventHandler(Form1_KeyDown);
        }

        private void PersonalInfo_Load(object sender, EventArgs e)
        {
            labelYeniSifre.Visible = false;
            labelYeniSifreOnay.Visible = false;
            txtYeniSifre.Visible = false;
            txtYeniSifreyiOnayla.Visible = false;
            btnOnayla.Visible = false;

            string projectDirectory = AppDomain.CurrentDomain.BaseDirectory;
            string filePath = Path.Combine(projectDirectory, "personal_info.csv");

            if (File.Exists(filePath))
            {
                try
                {
                    string[] lines = File.ReadAllLines(filePath);
                    if (lines.Length > 1)
                    {
                        string[] data = lines[1].Split(',');

                        txtName.Text = data[0];
                        txtSurname.Text = data[1];
                        txtPhone.Text = data[2];
                        txtAddress.Text = data[3];
                        txtEmail.Text = data[4];
                        txtPassword.Text = data[5];

                        // Fotoğrafı dosya yolundan yükleme
                        if (File.Exists(data[6]))
                        {
                            pictureBox.Image = Image.FromFile(data[6]);
                            photoBase64 = data[6];
                        }
                        else
                        {
                            MessageBox.Show("Fotoğraf bulunamadı.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Yükleme sırasında bir hata oluştu: {ex.Message}", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private Image Base64ToImage(string base64String)
        {
            byte[] imageBytes = Convert.FromBase64String(base64String);
            using (var ms = new MemoryStream(imageBytes, 0, imageBytes.Length))
            {
                ms.Write(imageBytes, 0, imageBytes.Length);
                return Image.FromStream(ms, true);
            }
        }

        private void btnUploadPhoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Image Files (*.png; *.jpg; *.bmp)|*.png;*.jpg;*.bmp"
            };
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                pictureBox.Image = Image.FromFile(openFileDialog.FileName);

                // Fotoğrafı 'Uploads' klasörüne kaydetme
                string uploadsDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Uploads");
                if (!Directory.Exists(uploadsDirectory))
                {
                    Directory.CreateDirectory(uploadsDirectory);
                }

                string fileName = Path.GetFileName(openFileDialog.FileName);
                string filePath = Path.Combine(uploadsDirectory, fileName);

                File.Copy(openFileDialog.FileName, filePath, true);

                // Dosya yolunu saklama
                photoBase64 = filePath;
            }
        }
        private Stack<string[]> undoStack = new Stack<string[]>();
        private Stack<string[]> redoStack = new Stack<string[]>();
        private void btnSave_Click(object sender, EventArgs e)
        {

            if (!ValidateInputs())
            {
                return;
            }

            SaveStateToUndoStack();

            var data = new
            {
                Name = txtName.Text,
                Surname = txtSurname.Text,
                Phone = txtPhone.Text,
                Address = txtAddress.Text,
                Email = txtEmail.Text,
                Password = txtPassword.Text,
                Photo = photoBase64 // Fotoğrafın dosya yolu
            };

            string projectDirectory = AppDomain.CurrentDomain.BaseDirectory;
            string filePath = Path.Combine(projectDirectory, "personal_info.csv");

            try
            {
                using (StreamWriter sw = new StreamWriter(filePath))
                {
                    sw.WriteLine("Name,Surname,Phone,Address,Email,Password,Photo");
                    sw.WriteLine($"{data.Name},{data.Surname},{data.Phone},{data.Address},{data.Email},{data.Password},{data.Photo}");
                }
                MessageBox.Show("Saved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while saving: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void SaveStateToUndoStack() // mevcut durumu undo yığınına kaydet
        {
            string[] currentState = new string[]
            {
        txtName.Text,
        txtSurname.Text,
        txtPhone.Text,
        txtAddress.Text,
        txtEmail.Text,
        txtPassword.Text,
        photoBase64
            };
            undoStack.Push(currentState);
            redoStack.Clear(); // Yeni bir işlem yapıldığında redo yığını temizlenir
        }

        private void Undo()
        {
            if (undoStack.Count > 0)
            {
                string[] currentState = new string[]
                {
            txtName.Text,
            txtSurname.Text,
            txtPhone.Text,
            txtAddress.Text,
            txtEmail.Text,
            txtPassword.Text,
            photoBase64
                };
                redoStack.Push(currentState);

                string[] previousState = undoStack.Pop();
                txtName.Text = previousState[0];
                txtSurname.Text = previousState[1];
                txtPhone.Text = previousState[2];
                txtAddress.Text = previousState[3];
                txtEmail.Text = previousState[4];
                txtPassword.Text = previousState[5];
                pictureBox.Image = Base64ToImage(previousState[6]);

                // Debug mesajı

            }
        }

        private void Redo()
        {
            if (redoStack.Count > 0)
            {
                string[] currentState = new string[]
                {
            txtName.Text,
            txtSurname.Text,
            txtPhone.Text,
            txtAddress.Text,
            txtEmail.Text,
            txtPassword.Text,
            photoBase64
                };
                undoStack.Push(currentState);

                string[] nextState = redoStack.Pop();
                txtName.Text = nextState[0];
                txtSurname.Text = nextState[1];
                txtPhone.Text = nextState[2];
                txtAddress.Text = nextState[3];
                txtEmail.Text = nextState[4];
                txtPassword.Text = nextState[5];
                pictureBox.Image = Base64ToImage(nextState[6]);
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.Z)
            {
                Undo();
            }
            else if (e.Control && e.KeyCode == Keys.Y)
            {
                Redo();
            }
        }

        private bool ValidateInputs()
        {
            string emailPattern = @"^\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b";
            string phonePattern = @"^\(\d{3}\) \d{3} \d{2} \d{2}$";

            if (!Regex.IsMatch(txtEmail.Text, emailPattern))
            {
                MessageBox.Show("Invalid email format.");
                return false;
            }

            if (!Regex.IsMatch(txtPhone.Text, phonePattern))
            {
                MessageBox.Show("Invalid phone format.");
                return false;
            }

            if (!IsValidPassword(txtPassword.Text))
            {
                MessageBox.Show("Invalid password format. Password must be at least 8 characters long, contain at least one uppercase letter, one lowercase letter, and one digit.");
                return false;
            }

            return true;
        }
        private bool IsValidPassword(string password)
        {
            // Şifrenin en az 8 karakter uzunluğunda olması, en az bir büyük harf, bir küçük harf ve bir rakam içermesi gerekmektedir
            if (password.Length < 8)
                return false;

            bool hasUpperChar = false, hasLowerChar = false, hasDecimalDigit = false;

            foreach (char c in password)
            {
                if (char.IsUpper(c)) hasUpperChar = true;
                else if (char.IsLower(c)) hasLowerChar = true;
                else if (char.IsDigit(c)) hasDecimalDigit = true;
            }

            return hasUpperChar && hasLowerChar && hasDecimalDigit;
        }

        private void btnSifreyiDegistir_Click(object sender, EventArgs e)
        {
            labelYeniSifre.Visible = true;
            labelYeniSifreOnay.Visible = true;
            txtYeniSifre.Visible = true;
            txtYeniSifreyiOnayla.Visible = true;
            btnOnayla.Visible = true;
        }

        private void btnOnayla_Click(object sender, EventArgs e)
        {
            string newPassword = txtYeniSifre.Text;
            string confirmPassword = txtYeniSifreyiOnayla.Text;

            if (newPassword != confirmPassword)
            {
                MessageBox.Show("Passwords do not match. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!IsValidPassword(newPassword))
            {
                MessageBox.Show("Invalid password format. Password must be at least 8 characters long, contain at least one uppercase letter, one lowercase letter, and one digit.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            txtPassword.Text = newPassword;

            // Update the CSV file
            string projectDirectory = AppDomain.CurrentDomain.BaseDirectory;
            string filePath = Path.Combine(projectDirectory, "personal_info.csv");

            try
            {
                using (StreamWriter sw = new StreamWriter(filePath))
                {
                    sw.WriteLine("Name,Surname,Phone,Address,Email,Password,Photo");
                    sw.WriteLine($"{txtName.Text},{txtSurname.Text},{txtPhone.Text},{txtAddress.Text},{txtEmail.Text},{txtPassword.Text},{photoBase64}");
                }
                MessageBox.Show("Your password has been changed and saved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while saving: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            labelYeniSifre.Visible = false;
            labelYeniSifreOnay.Visible = false;
            txtYeniSifre.Visible = false;
            txtYeniSifreyiOnayla.Visible = false;
            btnOnayla.Visible = false;
        }
    }
}

